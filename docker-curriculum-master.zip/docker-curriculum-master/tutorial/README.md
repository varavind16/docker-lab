# Tutorial

Static site content for [docker-curriculum.com](https://docker-curriculum.com) generated via [Metalsmith](http://www.metalsmith.io/) hosted on [Netlify](https://www.netlify.com/).

### Development

```
$ npm install
$ npm run start
```

### Contributions

For any contributions, make sure you suggest changes to [src/index.md](https://github.com/prakhar1989/docker-curriculum/blob/master/tutorial/src/index.md) and not the generated file (`index.html`).
